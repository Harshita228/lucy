//Author Name: Kartik Kumar
//Date: 23-10-2018
//Purpose: To test the script 
// File: VerifyRegistrationPageTestNG.java(TestNg class)
//Browser used: Chrome



package registration;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class VerifyRegistrationPageTestNG {

	public int TimeoutValue = 30;
	//Prioritizer priority ;
	public WebDriver driver ;
	public RegisterationPageFactory reg;

	@Test
	public void testCases() throws InterruptedException{
		//Create Chrome driver to LAunch Browser
				System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
				driver = new ChromeDriver();

				//1. Launch Chrome Browser
				driver.get("D://js-form-validation (1)//js-form-validation//example-javascript-form-validation.html");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				RegisterationPageFactory reg = new RegisterationPageFactory(driver);
				reg = PageFactory.initElements(driver, RegisterationPageFactory.class);//Initializing pagefactoory obj
				
				//Verify Title
				reg.testTitle("JavaScript Form Validation using a sample registration form");
				//verify UserId Alert message 
				reg.verifyUserId("12w7153");
				//verify Password Alert message 
				reg.verifyPassword("635473gere");
				//verify Name Alert message 
				reg.verifyName("Kartik");
				//verify Address Alert message 
				reg.verifyAddress("dhvjdf8786@");//with wrong data
				//verify Country dropdown  Alert message
				reg.verifyCountry(0);
				//verify Zip Code Alert message
				reg.verifyZip("3654hf");
				//verify Email Alert message
				reg.verifyEmail("jdhfjd76");
				Thread.sleep(2000);
				//Enter Sex
				reg.selectMaleSex();
				
				Thread.sleep(2000);
				//Select language
				reg.selectNonEngLanguage();
				Thread.sleep(2000);
				reg.verifyTextIsPresent();
				Thread.sleep(2000);
				reg.enterAbout("I am Kartik");
				Thread.sleep(2000);
				reg.submit.click();
				Thread.sleep(2000);
				//close the browser
				driver.close();
			
	}
	
  
}
