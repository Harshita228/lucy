//Author Name: Kartik Kumar
//Date :23-10-2018
//Purpose: To test the script 
// File: RegistrationPageFactory.java
package registration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegisterationPageFactory {



	public static WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public RegisterationPageFactory(WebDriver driver)
	{
		this.driver =driver;
	}

	@FindBy(xpath="/html/body/h4")
	@CacheLookup // to store the element in cache memory
	WebElement head;


	@FindBy(id="usrID")
	@CacheLookup // to store the element in cache memory
	WebElement userid;



	@FindBy(name="passid")
	@CacheLookup // to store the element in cache memory
	WebElement password;


	//using Xpath
	@FindBy(how=How.XPATH, using="//*[@id='usrname']")
	@CacheLookup
	WebElement name;


	@FindBy(name="country")
	@CacheLookup
	WebElement country;



	//using classname
	@FindBy(className="Format1")
	@CacheLookup
	WebElement address;
	//using Xpath
	@FindBy(how=How.XPATH, using="/html/body/form/ul/li[12]/input")
	@CacheLookup
	WebElement zip_code;

	//using Name
	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	//using Name
	@FindBy(name="sex")
	@CacheLookup
	WebElement sex;		

	//using Name
	@FindBy(name="en")
	@CacheLookup
	WebElement eng;		
	//using Xpath
	@FindBy(name="nonen")
	@CacheLookup
	WebElement noneng;	
//using id
	@FindBy(id="desc")
	@CacheLookup // to store the element in cache memory
	WebElement about;

	//using Name
	@FindBy(name="submit")
	@CacheLookup
	public WebElement submit;		

	
	
	@FindBy(how=How.XPATH, using="/html/body/p")
	@CacheLookup
	WebElement texttab;

	
	
		public void enterUserId(String id){
			userid.sendKeys(id);
		}

	public void enterName(String fname){
		name.sendKeys(fname);
	}

	public void enterPassword(String pass) {
		password.sendKeys(pass);
	}
	public void enterAddress(String pass) {
		address.sendKeys(pass);
	}
	public void selectCountry(int index) {
		Select countr = new Select(country); 
		countr.selectByIndex(index);
	}
	public String getTitle(){
		return driver.getTitle();
	}
	public void enterEmail(String em) {
		email.sendKeys(em);
	}
	public void enterZip(String z) {
		zip_code.sendKeys(z+"");
	}
	public void selectMaleSex() {
	sex.click();
	}
	public void selectEngLanguage() {
		eng.click();
		}
	public void selectNonEngLanguage() {
		noneng.click();
		}
	
	//verify text is present 
	public void verifyTextIsPresent(){
	Boolean txt= texttab.isDisplayed();
	if(txt){
		System.out.println(texttab.getText()+": Text Is present:: Text Test passed!");
	}
	else 
	{
		System.out.println(texttab.getText()+": Text Is Not Present:: Text Test passed Failed!");
	}
	}
	//test title
	public boolean testTitle(String expTitle){
		String actualTitle="";
		//boolean valid=false;
		actualTitle=driver.getTitle();
		if (actualTitle.contentEquals(expTitle)){
			System.out.println(actualTitle+": Title Test Passed!");
			return true;

		} else {
			System.out.println(actualTitle+": Title Test Failed");
			driver.quit();
			return false;
		}
	}
	
//verify pssword
	public void verifyPassword(String pass) throws InterruptedException  
	{
		Boolean p=name.isDisplayed();
		if(p=true) 
		{
			System.out.println("Password textbox present");
			enterPassword(""); //leaving blank
			submit.click();
			Thread.sleep(2000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="Password should not be empty / length be between 7 to 12";
			
			String actualAlertMessage= driver.switchTo().alert().getText();
			System.out.println(actualAlertMessage);
			if(expectedAlertMessage.contentEquals(actualAlertMessage))
			{
				System.out.println("Alert message verification for password - Passed");
				alert.accept();
				enterPassword(pass);
			}
			else
			{
				System.out.println("Alert message verification for password - Failed");
			}

		}
		else
			System.out.println("Password textbox is not present");
			
	}
	
	
	//
	public void verifyName(String fname) throws InterruptedException  
	{
		Boolean fn=name.isDisplayed();
		if(fn=true) 
		{
			System.out.println("Name textbox present");
			enterName("");//leaving blank
			submit.click();
			Thread.sleep(2000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="Username must have alphabet characters only";
			String actualAlertMessage= driver.switchTo().alert().getText();
			if(expectedAlertMessage.contentEquals(actualAlertMessage))
			{
				System.out.println("Alert message verification for name - Passed");
				alert.accept();
				enterName(fname);
			}
			else
			{
				System.out.println("Alert message verification for name - Failed");
			}

		}
		else
		{
			System.out.println("Name textbox not present");
		}
	}
	
	public void verifyUserId(String id) throws InterruptedException  
	{
		Boolean fn=userid.isDisplayed();
		if(fn=true) 
		{
			System.out.println("User Id textbox present");
			enterUserId(""); //leaving blank
			submit.click();
			Thread.sleep(2000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="User Id should not be empty / length be between 5 to 12";
			String actualAlertMessage= driver.switchTo().alert().getText();
			if(expectedAlertMessage.contentEquals(actualAlertMessage))
			{
				System.out.println("Alert message verification for User Id - Passed");
				alert.accept();
				enterUserId(id);
			}
			else
			{
				System.out.println("Alert message verification for User Id - Failed");
			}

		}
		else
		{
			System.out.println("User Id textbox not present");
		}
	}

	
	public RegisterationPageFactory(){
		driver= new ChromeDriver();
	}
	public boolean isAlertPresent(){
		 try{
		  driver.switchTo().alert();
		  return true;
		 }catch(NoAlertPresentException ex){
		  return false;
		 }
		}
	public void verifyAddress(String address) throws InterruptedException  
	{
		Boolean fn=userid.isDisplayed();
		if(fn=true) 
		{
			System.out.println("Address textbox present");
			enterAddress(address); //address
			submit.click();
			Thread.sleep(2000);
			
			if(isAlertPresent()){
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="User address must have alphanumeric characters only";
			String actualAlertMessage= driver.switchTo().alert().getText();
			if(expectedAlertMessage.contentEquals(actualAlertMessage))
			{
				System.out.println("Alert message verification for Address - Passed");
				alert.accept();
				this.address.clear();
				enterAddress("Mumbai");//valid data
			}
			else
			{
				System.out.println("Alert message verification for Address - Failed");
			}
			}

		}
		else
		{
			System.out.println("Address textbox not present");
		}
	}

	
	public void verifyCountry(int index) throws InterruptedException{
		boolean c = country.isDisplayed();
		if(c){
			System.out.println("Country dropdown is present");
			selectCountry(index); //address
			submit.click();
			Thread.sleep(2000);
			//System.out.println("SELECTED"+);
			if(isAlertPresent()){
				Alert alert = driver.switchTo().alert();
				String expectedAlertMessage="Select your country from the list";
				String actualAlertMessage= driver.switchTo().alert().getText();
				if(expectedAlertMessage.contentEquals(actualAlertMessage))
				{
					System.out.println("Alert message verification for Country - Passed");
					alert.accept();
					selectCountry(2);//valid data
				}
				else
				{
					System.out.println("Alert message verification for Country - Failed");
				}
				}

			}
			else
			{
				System.out.println("Country textbox not present");
			}
	}
	public void verifyZip(String n) throws InterruptedException
	{
		boolean c = zip_code.isDisplayed();
		if(c){
			System.out.println("Zip Code Field is present");
			enterZip(n);
			submit.click();
			Thread.sleep(2000);
			//System.out.println("SELECTED"+);
			if(isAlertPresent()){
				Alert alert = driver.switchTo().alert();
				String expectedAlertMessage="ZIP code must have numeric characters only";
				String actualAlertMessage= driver.switchTo().alert().getText();
				if(expectedAlertMessage.contentEquals(actualAlertMessage))
				{
					System.out.println("Alert message verification for Zip Code  - Passed");
					alert.accept();
					zip_code.clear();
					enterZip("3764");//valid data
				}
				else
				{
					System.out.println("Alert message verification for Zip Code  - Failed");
				}
				}

			}
			else
			{
				System.out.println("Zip Code Field not present");
			}
	}
	//Email verifcation
	public void verifyEmail(String n) throws InterruptedException
	{
		boolean c = email.isDisplayed();
		if(c){
			System.out.println("Email Field is present");
			enterEmail(n);
			submit.click();
			Thread.sleep(2000);
			//System.out.println("SELECTED"+);
			if(isAlertPresent()){
				Alert alert = driver.switchTo().alert();
				String expectedAlertMessage="You have entered an invalid email address!";
				String actualAlertMessage= driver.switchTo().alert().getText();
				if(expectedAlertMessage.contentEquals(actualAlertMessage))
				{
					System.out.println("Alert message verification for Email  - Passed");
					alert.accept();
					email.clear();
					enterEmail("kartik@gmail.com");//valid data
				}
				else
				{
					System.out.println("Alert message verification for Email  - Failed");
				}
				}

			}
			else
			{
				System.out.println("Email Field not present");
			}
	}
	
	public static void main(String []args) throws InterruptedException{
		//Create Chrome driver to LAunch Browser
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		driver = new ChromeDriver();

		//1. Launch Chrome Browser
		driver.get("D://js-form-validation (1)//js-form-validation//example-javascript-form-validation.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		RegisterationPageFactory reg = new RegisterationPageFactory(driver);
		reg = PageFactory.initElements(driver, RegisterationPageFactory.class);
		
		//Verify Title
		reg.testTitle("JavaScript Form Validation using a sample registration form");
		reg.verifyUserId("12w7153");
		reg.verifyPassword("635473gere");
		reg.verifyName("Kartik");
		reg.verifyAddress("dhvjdf8786@");
		reg.verifyCountry(0);
		reg.verifyZip("3654hf");
		reg.verifyEmail("jdhfjd76");
		Thread.sleep(2000);
		reg.selectMaleSex();
		Thread.sleep(2000);
		reg.selectNonEngLanguage();
		Thread.sleep(2000);
		reg.verifyTextIsPresent();
		Thread.sleep(2000);
		reg.enterAbout("I am Kartik");
		Thread.sleep(2000);
		reg.submit.click();
		

	}
	public void enterAbout(String abt) {
		about.sendKeys(abt);
	}

}
