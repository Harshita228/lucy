//Author Name: Kartik Kumar
//Date: 23-10-2018
//Purpose: To implement the Parameterize concept 
//Browser used: Chrome
// File: ParameterizeDemo.java



package
package paramerizatioQ2;

import java.io.File;
import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import registration.RegisterationPageFactory;

public class ParameterizeDemo {

	public static void main(String[] args) throws Exception {
		WebDriver driver;
		File src= new File("D:\\Chennai VnV batch\\m4\\Demos\\POM\\Data1.xlsx");
		//using Java API specify workbook path
		FileInputStream fis = new FileInputStream(src);
		//to load entire workbook use XSSFWorkbook class
		XSSFWorkbook wb1 = new XSSFWorkbook(fis);  //XSS used for .xlsx file
		//HSSFWorkbook wb1 = new HSSFWorkbook(fis); //HSS used for .xls file
		//to get the access of sheet 1 use XSSFSheet class
		XSSFSheet sheet1 = wb1.getSheetAt(0);
		/*//to read 1st row and col from sheet 1
		String data0 = sheet1.getRow(0).getCell(0).getStringCellValue();
		System.out.println("Data from Excel is " +data0);  */
		// to get the count of no. of rows present in sheet
		//	int rowcount = sheet1.getLastRowNum();
		//	System.out.println("Total no. of Rows" +rowcount);
		//Create Chrome driver to LAunch Browser
				System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
				driver = new ChromeDriver();
				//1. Launch Chrome Browser
				driver.get("D://js-form-validation (1)//js-form-validation//example-javascript-form-validation.html");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				driver.manage().window().maximize();
				RegisterationPageFactory reg = new RegisterationPageFactory(driver);
				reg = PageFactory.initElements(driver, RegisterationPageFactory.class);
		String username=sheet1.getRow(2).getCell(0).getStringCellValue();
		String password=sheet1.getRow(2).getCell(1).getStringCellValue();
		
		System.out.println(username);
		System.out.println(password);
			
		
		//Verify Title
		reg.testTitle("JavaScript Form Validation using a sample registration form");
		//verify UserId Alert message 
		reg.verifyUserId("12w7153");
		//verify Password Alert message 
		reg.verifyPassword(password);
		//verify Name Alert message 
		reg.verifyName(username);
		//verify Address Alert message 
		reg.verifyAddress("dhvjdf8786@");//with wrong data
		//verify Country dropdown  Alert message
		reg.verifyCountry(0);
		//verify Zip Code Alert message
		reg.verifyZip("3654hf");
		//verify Email Alert message
		reg.verifyEmail("jdhfjd76");
		Thread.sleep(2000);
		//Enter Sex
		reg.selectMaleSex();
		
		Thread.sleep(2000);
		//Select language
		reg.selectNonEngLanguage();
		Thread.sleep(2000);
		reg.verifyTextIsPresent();
		Thread.sleep(2000);
		reg.enterAbout("I am Kartik");
		Thread.sleep(2000);
		reg.submit.click();
		Thread.sleep(2000);
		//close the browser
	
//		
//		driver.get("D:\\Chennai VnV batch\\m4\\LoginDemoPage.html");
//		driver.findElement(By.id("un")).sendKeys(username);
//		driver.findElement(By.id("pass")).sendKeys(password);
//		driver.findElement(By.id("login")).click();
		
	//	driver.close();
		wb1.close();  
	}
}
