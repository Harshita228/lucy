package question3;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import question3.reg_form;


public class reg_form {
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public void ChromeHub(WebDriver driver)
	{
		this.driver =driver;
	}
	@FindBy(xpath="html/body/h4")
	WebElement heading;
	
	@FindBy(id="usrID")
	@CacheLookup // to store the element in cache memory
	WebElement userid;
	
	//using How class	
	@FindBy(how=How.NAME, using="passid")
	@CacheLookup
	WebElement password;
	
	//using Xpath
	@FindBy(how=How.ID, using="usrname")
	@CacheLookup
	WebElement Name;
	
	//using Xpath
		@FindBy(how=How.NAME, using="address")
		@CacheLookup
		WebElement Address;
		
		//using Xpath
				@FindBy(how=How.NAME, using="country")
				@CacheLookup
				WebElement country;
		
				//using Xpath
				@FindBy(how=How.NAME, using="zip")
				@CacheLookup
				WebElement ZIPCode;
				
				//using name for
				@FindBy(how=How.NAME, using="email")
				@CacheLookup
				WebElement Email;
				//using name for
				@FindBy(how=How.NAME, using="sex")
				@CacheLookup
				WebElement sex;
				//using name for
				@FindBy(how=How.XPATH, using="/html/body/form/ul/li[19]/span")
				@CacheLookup
				WebElement Language;
				
				@FindBy(id="desc")
				@CacheLookup // to store the element in cache memory
				WebElement About;
				
				@FindBy(linkText="Submit")
				WebElement Submit;
				
				public void login_misapp(String un, String pass, String shubham,String jaipur,String india,String pss,String mpal)
				{
					userid.sendKeys(un);
					password.sendKeys(pass);
					Name.sendKeys(shubham);
					Address.sendKeys(jaipur);
					((Alert) country).sendKeys(india);
					ZIPCode.sendKeys(pss);
					Email.sendKeys(mpal);
					WebElement sex = driver.findElement(By.xpath("//*[@id='gender']"));
					sex.click();
					Language.click();
					Submit.click();
				}
				public void enteruserid(String un)
				{
					userid.sendKeys(un);
				}
				public void enterpassword(String pass)
				{
					password.sendKeys(pass);
				}
				
				public void enterName(String shubham)
				{
					Name.sendKeys(shubham);
				}
				
				public void enterAddress(String jaipur)
				{
					Address.sendKeys(jaipur);
				}
				public void entercountry(String india)
				{

					country.sendKeys(india);
				}
				public void enterZIPCode(String pss)
				{
					ZIPCode.sendKeys(pss);
				}
				public void enterEmail(String mpal)
				{
					Email.sendKeys(mpal);
				}
				public void entersex(String male)
				{
					sex.sendKeys(male);
				}
				public void enterLanguage(String english)
				{
					Language.click();
				}
			
				public void verifyTitle(String expected)
				{
					String actual = driver.getTitle();
					if(actual.contentEquals(expected))
					{
						System.out.println("Title Verification - Passed");
					}
					else
					{
						System.out.println("Title Verification - Failed");
						driver.quit();
					}
						
				}
				public void verifyHeading(String expected)
				{
					String actual = heading.getText();
					if(actual.contentEquals(expected))
					{
						System.out.println("Heading Verification - Passed");
						 
					}
					else
					{
						System.out.println("Heading Verification - Failed");
						driver.quit();
					}
						
				}
				
				@SuppressWarnings("unused")
				public void verifyuserid() throws InterruptedException  
				{
					userid.isDisplayed();
					if(true) 
					{
						System.out.println("userid textbox present");
						enteruserid("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Please fill the userid";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for userid - Passed");
					    	alert.accept();
					    	enteruserid("shpalsan");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for userid - Failed");
						}
					    
					}
					else
					{
						System.out.println("userid textbox not present");
					}
					
				}
				@SuppressWarnings("unused")
				public void verifypassword() throws InterruptedException  
				{
					password.isDisplayed();
					if(true) 
					{
						System.out.println("password textbox present");
						enteruserid("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Password should not be empty / length be between 7 to 12";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for password - Passed");
					    	alert.accept();
					    	enterpassword("palsaniya");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for password - Failed");
						}
					    
					}
					else
					{
						System.out.println("password textbox not present");
					}
					
				}
				@SuppressWarnings("unused")
				public void verifyName() throws InterruptedException  
				{
					Name.isDisplayed();
					if(true) 
					{
						System.out.println("Name textbox present");
						enterName("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Please fill the Name";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for Name - Passed");
					    	alert.accept();
					    	enterName("shubham palsaniya");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for Name - Failed");
						}
					    
					}
					else
					{
						System.out.println("Name textbox not present");
					}
					
				}
				
				@SuppressWarnings("unused")
				public void verifyAddress() throws InterruptedException  
				{
					Address.isDisplayed();
					if(true) 
					{
						System.out.println("Address textbox present");
						enterName("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="User address must have alphanumeric characters only";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for Address - Passed");
					    	alert.accept();
					    	enterAddress("jaipur");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for Address - Failed");
						}
					    
					}
					else
					{
						System.out.println("Address textbox not present");
					}
					
				}
				@SuppressWarnings("unused")
				public void verifycountry() throws InterruptedException  
				{
					((WebElement) country).isDisplayed();
					if(true) 
					{
						System.out.println("Address textbox present");
						entercountry("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Please fill the country";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for country - Passed");
					    	alert.accept();
					    	entercountry("india");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for country - Failed");
						}
					    
					}
					else
					{
						System.out.println("country textbox not present");
					}
					
				}
				@SuppressWarnings("unused")
				public void verifyZipCode() throws InterruptedException  
				{
					ZIPCode.isDisplayed();
					if(true) 
					{
						System.out.println("ZIPCode textbox present");
						enterZIPCode("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Please fill the ZIPCode";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for ZIPCode - Passed");
					    	alert.accept();
					    	enterZIPCode("302006");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for ZIPCode - Failed");
						}
					    
					}
					else
					{
						System.out.println("ZIPCode textbox not present");
					}
					
				}
				@SuppressWarnings("unused")
				public void verifyEmail() throws InterruptedException  
				{
					Email.isDisplayed();
					if(true) 
					{
						System.out.println("Email textbox present");
						enterZIPCode("");
						Submit.click();
						Thread.sleep(3000);;
						Alert alert = driver.switchTo().alert();
						String expectedAlertMessage="Please fill the Email";
					    String actualAlertMessage= driver.switchTo().alert().getText();
					    if(expectedAlertMessage.contentEquals(actualAlertMessage))
					    {
					    	System.out.println("Alert message verification for Email - Passed");
					    	alert.accept();
					    	enterEmail("mpal@gmail.com");
					    }
					    else
					    {
					    	System.out.println("Alert message verification for Email - Failed");
						}
					    
					}
					else
					{
						System.out.println("Email textbox not present");
					}
					
				}
				public static void main(String args[]) throws MalformedURLException
				{
					System.setProperty("webdriver.chromedriver.driver", "D:\\chromedriver.exe");
					DesiredCapabilities capabilities = DesiredCapabilities.chrome();
					capabilities.setBrowserName("chrome");
					capabilities.setCapability("webdriver.chromedriver.driver", "D:\\chromedriver.exe");
						
					capabilities.setPlatform(Platform.WINDOWS);
					//capabilities.setVersion(version);
					WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
					driver.get("D:\\example-javascript-form-validation.html");
					//LoginPageFactory login = new LoginPageFactory(driver);
					
					//Initializing web element using initElement method
					
					reg_form reg_page = PageFactory.initElements(driver, reg_form.class);
					reg_page.enteruserid("shpalsan");
					reg_page.enterpassword("palsaniya");
					reg_page.enterName("shubham palsaniyai");
					reg_page.enterAddress("jaipur");
					reg_page.entercountry("india");
					reg_page.enterZIPCode("302006");
					reg_page.enterEmail("mpal375@gmail.com");
				}
}
