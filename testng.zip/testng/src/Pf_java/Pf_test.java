package Pf_java;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pf_java.RegistrationFormPageFactory;

public class Pf_test {
	static WebDriver driver;
	RegistrationFormPageFactory registrationFormPageFactory;
	@BeforeClass
	public void beforeClass()
	{
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		driver= new ChromeDriver();

		//2.	Open the web page �ConferenceRegistartion.html � in the browser.
		driver.get("file:///C:/Users/shpalsan/Desktop/vnv/m4/Case%20Study/ConferenceRegistartion.html");
		registrationFormPageFactory = PageFactory.initElements(driver,RegistrationFormPageFactory.class);
	}
	
	@Test(priority=1)
	  public void verifyTitleTest() {
		
		String expectedTitle=" Conference Registartion";
		  registrationFormPageFactory.verifyTitle(expectedTitle);
	  }
	
	@Test(priority=1)
	  public void verifyHeadingTest() {
		String expectedHeading="Conference Registration";
		  registrationFormPageFactory.verifyHeading(expectedHeading);
	  }
	
	@Test(priority=1)
	  public void enterFirstname() throws InterruptedException {
		if(registrationFormPageFactory.isFnameFieldDisplayed())
		  registrationFormPageFactory.enterFirstName("Lucyhhh");
		Thread.sleep(5000);
	  }
	
	@Test(priority=2)
	  public void enterLastname() {
		if(registrationFormPageFactory.isLnameFieldDisplayed())
		  registrationFormPageFactory.enterLastname("Jhaaaaaaa");
	  }
	
	
  @Test(priority=3)
  public void enterEmail() {
	  if(registrationFormPageFactory.isemailFieldDisplayed())
	  registrationFormPageFactory.enterEmail("Hello");
	  
  }
  
  @Test(priority=4)
  public void enterphone() {
	  if(registrationFormPageFactory.isphoneFieldDisplayed())
	  registrationFormPageFactory.enterPhone("ok");
  }
  
  @Test(priority=5)
  public void selectpeopleattending() {
	  if(registrationFormPageFactory.isSelectPeopleDropDownDisplayed())
	  registrationFormPageFactory.selectpeople(2);
  }
  
  @Test(priority=6)
  public void enteraddress() {
	  if(registrationFormPageFactory.isaddressFieldDisplayed())
	  registrationFormPageFactory.enteraddress("india");
  }
  
  @Test(priority=7)
  public void enteraddtrerss2() {
	  if(registrationFormPageFactory.isaddresssFieldDisplayed())
	  registrationFormPageFactory.enteraddress("mumbai");
  }
 
  @Test(priority=8)
  public void selectCityTest() {
	  if(registrationFormPageFactory.isSelectCityDropDownDisplayed())
	  registrationFormPageFactory.selectCity(2);
  }
  
  @Test(priority=9)
  public void selectStateTest() {
	  if(registrationFormPageFactory.isSelectStateDropDownDisplayed())
	  registrationFormPageFactory.selectState(3);
  }
  
  @Test(priority=10)
  public void selectLangEngTest() {
	  if(registrationFormPageFactory.isMemberRadioFieldDisplayed())
	  registrationFormPageFactory.selectMember(true);
	  
  }
  
  @Test(priority=11)
  public void selectNonLangEngTest() {
	  if(registrationFormPageFactory.isNonmemberRadioFieldDisplayed())
	  registrationFormPageFactory.selectNonMember(true);
  }
  

  
  @Test(priority=13)
  public void click_next() {
	  if(registrationFormPageFactory.isNextBtnDisplayed())
	  registrationFormPageFactory.click_next();
  }
}
