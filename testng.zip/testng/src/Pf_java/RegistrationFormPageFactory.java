/**
 * 
 */
package Pf_java;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

/**
 * @author Lucy
 *
 */
public class RegistrationFormPageFactory {
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public RegistrationFormPageFactory(WebDriver driver)
	{
		this.driver =driver;
	}
	//For Heading
	@FindBy(xpath="/html/body/h2")
	@CacheLookup // to store the element in cache memory
	public WebElement heading;
	
	//For Firstname
	@FindBy(id="txtFirstName")
	@CacheLookup // to store the element in cache memory
	public WebElement firstname;
	
	@FindBy(xpath="//*[@id='txtLastName']")
	@CacheLookup // to store the element in cache memory
	public WebElement lastname;
	
	//using How class	
	@FindBy(how=How.ID, using="txtEmail")
	@CacheLookup
	public WebElement email;
	
	//using Xpath
	@FindBy(how=How.XPATH, using="//*[@id='txtPhone']")
	@CacheLookup
	public WebElement phone;
	
	@FindBy(name="size")
	@CacheLookup
	public WebElement peopleAttending;
	
	@FindBy(name="Address")
	@CacheLookup
	public WebElement address;
	
	@FindBy(name="Address2")
	@CacheLookup
	public WebElement Address2;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	public WebElement city ;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	public WebElement state;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[12]/td[2]/input")
	@CacheLookup
	public WebElement member;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[13]/td[2]/input")
	@CacheLookup
	public WebElement nonmember;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	public WebElement next;

	public void enterFirstName(String fname)
	{
		firstname.sendKeys(fname);	
	}
	
	public void enterLastname(String lname)
	{
		lastname.sendKeys(lname);
	}
	
	public void enterEmail(String mail)
	{
		email.sendKeys(mail);
	}
	
	public void enterPhone(String phoneNo)
	{
		phone.sendKeys(phoneNo);
	}
	public void selectpeople(int peopleAttendingEvent)
	{
		Select sel=new Select(peopleAttending);
		sel.selectByIndex(peopleAttendingEvent);
	}
	
	public void enteraddress(String addr)
	{
		address.sendKeys(addr);
	}
	
	public void enteraddress2(String addr2)
	{
		Address2.sendKeys(addr2);
	}
	
	public void selectCity(int cityIndex)
	{
		Select sel=new Select(city);
		sel.selectByIndex(cityIndex);
	}
	
	public void selectState(int stateIndex)
	{
		Select sel=new Select(state);
		sel.selectByIndex(stateIndex);
	}
	public void selectMember(boolean isClicked)
	{
		if(isClicked)
			member.click();
	}
	public void selectNonMember(boolean isClicked)
	{
		if(isClicked)
			nonmember.click();
	}
	
	
	
	public void click_next(){
		next.click();
	}
	
	//Methhods to check whether the fields are displayed and enabled
	public boolean isFnameFieldDisplayed()
	{
		if(firstname.isDisplayed()&&firstname.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isLnameFieldDisplayed()
	{
		if(lastname.isDisplayed()&&lastname.isEnabled())
		{
			return true;
		}
		else
			return false;
	
	}
	
	public boolean isemailFieldDisplayed()
	{
		if(email.isDisplayed()&&email.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isphoneFieldDisplayed()
	{
		if(phone.isDisplayed()&&phone.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isSelectPeopleDropDownDisplayed()
	{
		if(peopleAttending.isDisplayed()&&peopleAttending.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	

	
	public boolean isaddressFieldDisplayed()
	{
		if(address.isDisplayed()&&address.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isaddresssFieldDisplayed()
	{
		if(Address2.isDisplayed()&&Address2.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isSelectCityDropDownDisplayed()
	{
		if(city.isDisplayed()&&city.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isSelectStateDropDownDisplayed()
	{
		if(state.isDisplayed()&&state.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	
	public boolean isMemberRadioFieldDisplayed()
	{
		if(member.isDisplayed()&&member.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isNonmemberRadioFieldDisplayed()
	{
		if(nonmember.isDisplayed()&&nonmember.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	
	public boolean isNextBtnDisplayed()
	{
		if(next.isDisplayed()&&next.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
			
	public void verifyTitle(String expected)
	{
		String actual = driver.getTitle();
		if(actual.contentEquals(expected))
		{
			//System.out.println("Title Verification - Passed");
		}
		else
		{
			//System.out.println("Title Verification - Failed");
			driver.quit();
		}
			
	}
	public void verifyHeading(String expected)
	{
		String actual = heading.getText();
		if(actual.contentEquals(expected))
		{
			//System.out.println("Heading Verification - Passed");
			 
		}
		else
		{
			//System.out.println("Heading Verification - Failed");
			driver.quit();
		}
			
	}
	
	public void verifyuserId() throws InterruptedException  
	{
		Boolean fn=firstname.isDisplayed();
		if(fn) 
		{
			System.out.println("First Name textbox present");
			enterFirstName("");
			next.click();
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="First name should not be empty / length be between 5 to 12";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for first name - Passed");
		    	alert.accept();
		    	enterFirstName("Lucy");
		    }
		    else
		    {
		    	System.out.println("Alert message verification for first name - Failed");
			}
		    
		}
		else
		{
			System.out.println("First Name textbox not present");
		}
		
	}
}
