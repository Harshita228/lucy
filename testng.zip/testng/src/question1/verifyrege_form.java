package question1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import question3.reg_form;

public class verifyrege_form {
	WebDriver driver ;
	reg_form  reg_page;
	public int TimeoutValue = 30;
			
	
	
	@Test(priority=1)
	public void TestCaseOne()
	{
		//1.	Launch the application browser
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//2.	Open the web page �ConferenceRegistartion.html � in the browser.
		driver.get("D:\\example-javascript-form-validation.html");
		reg_page = PageFactory.initElements(driver, reg_form .class);
		
		//3.	Verify the title �Conference Registration� of the page. 
		//The test should stop execution if the title of the page is not matching with the expected title.
		reg_page.verifyTitle("Registration Form");
		
		//4. Verify the heading  �Step 1: Personal Details � of the page. 
		//The test should stop execution if the heading of the page is not matching with the expected heading.
		reg_page.verifyHeading("Step 1: Personal Details");
		
	}         
	@Test(priority=2)
	public void TestCaseTwo() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifyuserid();
		
	}
	@Test(priority=3)
	public void TestCaseThree() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifypassword();
		
	}
	@Test(priority=4)
	public void TestCasefour() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifyName();
		
	}
	@Test(priority=5)
	public void TestCasefive() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifyAddress();
		
	}
	@Test(priority=6)
	public void TestCasesix() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifycountry();
		
	}
	@Test(priority=7)
	public void TestCaseseven() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifyZipCode();
		
	}
	@Test(priority=8)
	public void TestCaseeight() throws InterruptedException
	{
		//5a. Verifying availablity of first name text box
		//5b. Ensure that the alert box displays the message �Please fill the First Name� 
		//upon clicking on the link �Next� without entering any data in the text box.
      	//5c. Enter value for first name
		reg_page.verifyEmail();
		
	}

}
